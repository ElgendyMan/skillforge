# Project TODO

- [x] Define the product domain model for candidates, companies, supervisors, tests, questions, attempts, reviews, proctoring sessions, recordings, and notifications.
- [x] Add server-side role guards for candidate/company/supervisor procedures and enforce ownership checks on every test, attempt, review, notification, and file-access query/mutation.
- [x] Implement and test permission-scoped access rules so each company only sees its own tests/attempts and each candidate only sees their own attempts/recordings.
- [x] Add unit tests covering forbidden cross-company and cross-candidate access, plus supervisor-only access paths.
- [x] Implement candidate and company profile screens with authenticated editing, company-logo upload, and a public company page; supervisor administration uses its protected oversight console.
- [x] Apply and verify the RTL landing page implementation in `client/src/pages/Home.tsx` with polished sections, Arabic copy, and clear CTA/navigation.
- [x] Update `client/src/App.tsx`, `client/index.html`, and `client/src/index.css` to register the product routes, set Arabic/RTL metadata, and ship the intended visual system.
- [x] Run typecheck/build after the frontend changes and confirm the new navigation paths compile cleanly.
- [x] Finish and verify the test discovery page UI, including a company filter control wired to catalog.list and clean loading/empty/error states.
- [x] Build a multi-section company test creation wizard with MCQ, essay, code, vulnerability discovery, and file-upload questions.
- [x] Build the candidate test runner with countdown, autosave, section navigation, code editor, and evidence attachment flow.
- [x] Fix `TestRunner` recording lifecycle: store the screen recorder ref, stop both recorders cleanly, and log `camera_stopped` / related events when tracks end.
- [x] Link uploaded camera/screen recording assets back to `proctoringSessions` so review queries return usable recording asset IDs.
- [x] Add reviewer/candidate UI actions that call `files.secureAccess` for evidence and recordings, with loading/error states and permission-aware rendering.
- [x] Add tests covering proctoring event logging, integrity-flag classification, and permission-scoped file access for candidate/company/supervisor roles.
- [x] Add procedure-level tests that reject candidate/company/supervisor cross-role dashboard access before data queries execute.
- [x] Add procedure-level fail-closed tests for unowned candidate attempts and non-company review access; storage access remains covered by the company-member/owner/supervisor permission tests.
- [x] Add an explicit catalog-query error state in the candidate discovery interface.
- [x] Add status-transition validation tests for accepted, rejected, and under review decisions.
- [x] Finish and verify the company dashboard page UI wired to company.dashboard, showing published tests, attempts, pending review, and average performance with proper states.
- [x] Build the company review page with answers, scores, event timeline, integrity indicators, reviewer notes, and priority recommendation.
- [x] Implement candidate application-status tracking with the exact values accepted, rejected, and under review.
- [x] Implement notifications for new submitted attempts and candidate status changes.
- [x] Prepare outbound Resend delivery with configuration validation and safe `not_configured` fallback; real dispatch is deliberately deferred until the user supplies credentials and a verified sender address.
- [x] Build supervisor oversight screens for organization and attempt visibility within authorized scope.
- [x] Add server unit tests for role authorization, isolation, status transitions, and priority recommendation behavior.
- [x] Run type checks, unit tests, and visual responsive verification; resolve discovered issues.
- [x] Save a final project checkpoint and deliver the completed project.

- [x] Add a company-scoped candidate-comparison query and side-by-side decision view for two to four selected candidates.
- [x] Add permission-scoped inline code-review comments tied to an attempt answer and source-code line number.
- [x] Add company review controls to create, list, and remove their own code comments without exposing comments across companies.
- [x] Add visible test-time countdown and debounced autosave status to the candidate code editor.
- [x] Add regression tests for comparison isolation, code-comment ownership, line validation, and editor timer/autosave state helpers.
- [x] Run typecheck, tests, production build, visual verification, and save a new checkpoint.
- [x] Hide delete controls for comments not owned by the active reviewer and surface delete failures clearly.
- [x] Track real queued/saving/saved/error autosave state and flush pending answers before submit or unmount.
- [x] Add router-level review-tools isolation tests and include client assessment-safety helpers in the Vitest suite.
- [x] Re-run final verification and save the new checkpoint after closing review gaps.
- [x] Save the verified post-fix project state as a new checkpoint.
- [x] Add structured job titles to tests and company-scoped comparison filters for job title, question type, and submitted-date range.
- [x] Publish read-only code-review comments to the owning candidate only after accepted or rejected decisions.
- [x] Add protected comparison export as CSV and a browser-printable RTL PDF view.
- [x] Split heavy client routes and configure Vite manual chunks to reduce the initial JavaScript bundle.
- [x] Add regression tests for filters, published-feedback privacy, CSV escaping, lazy routes, and production chunk output.
- [x] Run migration, verification, visual checks, and save a new checkpoint.
- [x] Add an automated source-level regression test for lazy route registration and Suspense fallback.
- [x] Add an automated assertion that the production build emits deferred page chunks and explicit vendor chunks.
- [x] Re-run the complete verification after bundle-regression coverage and save a final checkpoint.
- [x] Save the verified filter, feedback, export, and bundle-regression changes as a final checkpoint.
- [x] Notify the owning candidate in-platform when code-review feedback becomes publishable after a final decision.
- [x] Add company-scoped saved comparison-filter templates with create, list, apply, and remove operations.
- [x] Add selectable CSV export columns while preserving safe comparison data and correct CSV escaping.
- [x] Add regression tests for notification idempotency, template company isolation, and CSV-column selection.
- [x] Run migration, verification, visual checks, and save a new checkpoint.
- [x] Save the verified feedback-notification, filter-template, and CSV-column changes as a new checkpoint.
- [x] Audit production configuration, environment usage, dependency health, and build output.
- [x] Audit server authorization, data isolation, notification idempotency, and database migration consistency.
- [x] Audit client loading, error boundaries, accessibility, responsive behavior, and production performance.
- [x] Fix all verified production blockers and add targeted regression coverage.
- [x] Resolve dashboard-route fallback behavior and replace the generic 404 with a branded RTL SkillForge recovery state.
- [x] Fix mobile horizontal overflow in the company dashboard and verify company views at narrow widths.
- [x] Verify and harden Express 5 storage-proxy matching with an automated route-level regression test.
- [x] Verify all lazy-loaded route export names at build/test time and fix any mismatches.
- [x] Reconcile production resource headers with external analytics and logo delivery after browser verification.
- [x] Run complete production verification, document readiness, and save a release checkpoint.
- [x] Perform and document a focused accessibility pass for keyboard focus, labels, semantic structure, and recovery states.
- [x] Verify company-dashboard responsive structure and document the authenticated narrow-viewport smoke test required after the first company workspace is activated.
- [x] Verify signed storage delivery and external analytics loading with the final production headers; no company logo exists yet in the audit database.
- [x] Re-run release validation and save the final production checkpoint after closing audit gaps.
- [x] Add company-scoped candidate notes and custom tags that are editable from the comparison view.
- [x] Show candidate notes and tags in comparison cards without exposing them outside the owning company.
- [x] Improve the company dashboard and comparison controls for narrow mobile layouts.
- [x] Add export loading animation, disabled state, and success/failure confirmation for CSV and PDF comparison exports.
- [x] Add regression tests for notes/tags isolation and export interaction states, then verify mobile layouts.
- [x] Run migration, complete verification, and save a new checkpoint.
- [x] Add source-level regression coverage for export loading, disabled controls, and success/failure confirmations.
- [x] Add responsive-structure regression coverage for the company comparison and dashboard shell.
- [x] Reconfirm responsive company-dashboard structure; run a final authenticated data-flow smoke test when company attempts exist, then save the checkpoint.
- [x] Fix /candidate role gating so supervisor accounts are redirected to the supervisor workspace before candidate queries run.
- [x] Add regression coverage for role-based landing routes and disabled candidate queries for non-candidates.
- [x] Run typecheck, tests, visual verification, and save a checkpoint for the role-routing fix.
- [x] Save the verified supervisor role-routing fix as a new checkpoint.
- [x] Show a clear permission-mismatch message with the current role and a button to its workspace instead of silently redirecting.
- [x] Add E2E-style coverage for candidate, company, and supervisor route protection and workspace switching.
- [x] Run typecheck, tests, build, visual verification, and save a new checkpoint.

- [x] Add real browser E2E coverage that exercises mismatched role URLs, explanatory UI, and workspace button navigation.
- [x] Save a checkpoint after the real browser E2E test passes.

- [x] Add a development-only mock-data mode with clearly labeled candidate, company, and supervisor fixtures; never enable it for production.
- [x] Add a repeatable large mock-data generator covering tests, questions, attempts, reviews, notifications, recordings, comparisons, notes, and tags with role ownership boundaries.
- [x] Add development authentication fixtures for candidate, company, and supervisor sessions without bypassing production Manus OAuth.
- [x] Add server regression tests proving mock-data ownership isolation and role-specific access for all three roles.
- [x] Add browser E2E coverage for each role using mock sessions, including route access, workspace navigation, key buttons, and auth/logout behavior.
- [x] Run visual verification for all role workspaces at desktop and mobile sizes and resolve interaction or layout defects.
- [x] Run typecheck, Vitest, E2E, production build, and save a new checkpoint with all work complete.

- [x] Add seeded-fixture authorization tests that exercise candidate, company, and supervisor procedures and deny cross-role or cross-owner access.
- [x] Explicitly review all three seeded role workspaces at desktop and mobile sizes, including the company dashboard after data settles, and record the result.

- [x] Open and inspect the final settled screenshots for candidate, company, and supervisor on both desktop and mobile, then record a complete six-variant visual review.

- [x] Audit all current routes, pages, controls, dialogs, dropdowns, tabs, forms, filters, states, and user workflows; create the element-to-function UI map.
- [x] Refactor role navigation progressively without deleting routes, controls, labels, handlers, or changing behavior.
- [x] Reorganize page-level primary, secondary, and advanced actions while preserving all existing state and workflows.
- [x] Verify responsive desktop/tablet/mobile layouts and accessibility for the reorganized navigation and controls.
- [x] Add UI regression and Playwright coverage proving every existing option remains reachable and functional after reorganization.
- [x] Run final typecheck, Vitest, Playwright, production build, visual review, and save a new checkpoint.

- [x] Complete the explicit per-route/per-page/per-control UI inventory and map every existing option, state, and workflow.
- [x] Expand browser regression coverage for all grouped secondary links and key page-level controls: candidate profile/notifications/files, company tests/profile/notifications/files, supervisor paths, filters, dialogs, and exports.

- [x] Group the company test-builder question-type actions under a labeled add-question menu while preserving every type and handler.
- [x] Complete the public-page and remaining-component inventory in ui-ux-element-map.md, including Home, NotFound, ComponentShowcase, and CompanyComparisonExperience.
- [x] Run tablet screenshots and explicit keyboard/focus/ARIA checks for the reorganized navigation and collapsible filter controls.

- [x] Open and document candidate, company, and supervisor tablet screenshots after the refactor, with keyboard/focus/ARIA checks active at tablet size.

- [x] Implement and verify the new requirements contained in the latest attached specification without breaking existing routes, role isolation, or workflows.

- [x] Produce a factual feature-gap inventory against the attached fairness, privacy, RBAC, audit, storage, runner, proctoring, notification, export, and documentation requirements.
- [x] Verify server-side attempt/review/hiring-decision state boundaries and ensure no score, flag, recording event, or AI signal can create an automatic hiring decision.
- [x] Verify published test/question immutability and version references; add safe versioning or document the remaining gap without silently changing active attempts.
- [x] Add candidate-facing assessment explanation, proctoring consent/alternative flow, technical-issue path, accommodation policy, retention summary, and review/appeal guidance where supported.
- [x] Verify code-runner and proctoring limitations are honestly surfaced as sandbox/provider-dependent; do not claim production isolation without evidence.
- [x] Harden evidence/storage validation, signed access, retention boundaries, export privacy, notification previews, and audit coverage where applicable.
- [x] Update the required fairness, privacy, security, RBAC, retention, appeals, and production-readiness documentation with explicit mock/sandbox/production boundaries.
- [x] Add regression coverage for the new boundaries and run full typecheck, unit/integration, Playwright, security, build, and visual verification before checkpoint.

- [x] Implement immutable assessment snapshots/versioned reads so active and past attempts load frozen sections/questions for their recorded test version.
- [x] Add a dedicated pre-start candidate disclosure step covering scoring, human review, proctoring limits, retention, alternatives, accommodations, and appeals.
- [x] Wire approved no-camera/alternative accommodations into test-start and proctoring behavior without bypassing consent or security checks.
- [x] Add regression and Playwright coverage for technical-issue pause, appeal creation, accommodation visibility, and immutable attempt content after later test changes.

- [x] Surface provider-dependent code-runner and proctoring limitations in the pre-start disclosure and runner UI, not only in documentation.
- [x] Audit runner/proctoring copy across the application and remove any claims of guaranteed isolation or infallible anti-cheating.

- [x] Add an integration test that starts a real attempt, changes source test/question content, and verifies candidate/company reads still use frozen snapshot content.
- [x] Mention appeal availability and its limits explicitly in the pre-start disclosure and assert the text in Playwright.
- [x] Apply and surface approved no_camera accommodation in the pre-start/start response, with regression coverage proving the alternative is visible before starting and consent is not bypassed.
- [x] Exercise technical-issue pause submission and appeal creation in regression/browser tests, not only dialog visibility.

- [x] Add an integration test that changes live test/question content and verifies candidate/company reads still use frozen snapshot content.
- [x] Surface provider-dependent code-runner/proctoring limits and explicit appeal availability/limits in the candidate pre-start disclosure and runner UI.

- [x] Add pending/quarantine file security workflow with audit logging and denied signed access until supervisor review.
