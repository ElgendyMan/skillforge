import { describe, expect, it } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";
import { canRemoveCodeReviewComment, canRemoveComparisonTemplate, comparedAttemptsMatchRequest, hasCompanyReviewAccess, isFinalApplicationStatus, isValidCodeCommentLine, isWithinSubmittedRange, normalizeCandidateTags } from "./reviewTools";

function createContext(role: "candidate" | "company" | "supervisor"): TrpcContext {
  return { user: { id: 42, openId: `review-tools-${role}`, name: "Test user", email: "test@example.com", loginMethod: "test", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { clearCookie: () => undefined } as TrpcContext["res"] };
}

describe("review tool access guards", () => {
  it("limits comparison tools to company members", () => {
    expect(hasCompanyReviewAccess("company")).toBe(true);
    expect(hasCompanyReviewAccess("candidate")).toBe(false);
    expect(hasCompanyReviewAccess("supervisor")).toBe(false);
  });

  it("fails closed when even one comparison attempt lies outside the company", () => {
    expect(comparedAttemptsMatchRequest([11, 12], [12, 11])).toBe(true);
    expect(comparedAttemptsMatchRequest([11, 12], [11])).toBe(false);
    expect(comparedAttemptsMatchRequest([11, 12], [11, 13])).toBe(false);
  });

  it("allows deleting a comment only for its original reviewer inside the owning company", () => {
    expect(canRemoveCodeReviewComment({ isCompanyOwner: true, isOriginalReviewer: true })).toBe(true);
    expect(canRemoveCodeReviewComment({ isCompanyOwner: true, isOriginalReviewer: false })).toBe(false);
    expect(canRemoveCodeReviewComment({ isCompanyOwner: false, isOriginalReviewer: true })).toBe(false);
  });

  it("allows removing a shared filter template only for its creator inside the owning company", () => {
    expect(canRemoveComparisonTemplate({ isCompanyOwner: true, isOriginalCreator: true })).toBe(true);
    expect(canRemoveComparisonTemplate({ isCompanyOwner: true, isOriginalCreator: false })).toBe(false);
    expect(canRemoveComparisonTemplate({ isCompanyOwner: false, isOriginalCreator: true })).toBe(false);
  });
});

describe("code comment line validation", () => {
  it("accepts valid submitted-code lines and rejects invalid values", () => {
    expect(isValidCodeCommentLine(1, "const x = 1;\nconsole.log(x);")).toBe(true);
    expect(isValidCodeCommentLine(2, "const x = 1;\nconsole.log(x);")).toBe(true);
    expect(isValidCodeCommentLine(0, "const x = 1;")).toBe(false);
    expect(isValidCodeCommentLine(3, "const x = 1;\nconsole.log(x);")).toBe(false);
    expect(isValidCodeCommentLine(1.5, "const x = 1;")).toBe(false);
  });
});

describe("review tool procedures", () => {
  it("rejects non-company callers before comparison or comment data can be queried", async () => {
    const candidate = appRouter.createCaller(createContext("candidate"));
    const supervisor = appRouter.createCaller(createContext("supervisor"));
    await expect(candidate.reviewTools.comparison({ attemptIds: [1, 2] })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(supervisor.reviewTools.comments.list({ attemptId: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(candidate.reviewTools.comments.remove({ commentId: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(candidate.reviewTools.comparisonCandidates({})).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(candidate.reviewTools.candidateAnnotations.upsert({ attemptId: 1, note: "خاص", tags: ["مناسب"] })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

describe("candidate annotation tags", () => {
  it("normalizes tags, removes duplicates, and enforces the team-facing limit", () => {
    expect(normalizeCandidateTags(["  مناسب للمقابلة ", "قوي   في  Burp", "مناسب للمقابلة", ""])).toEqual(["مناسب للمقابلة", "قوي في Burp"]);
    expect(normalizeCandidateTags(Array.from({ length: 15 }, (_, index) => `tag-${index}`))).toHaveLength(12);
  });
});

describe("comparison dates and published feedback", () => {
  it("matches only submitted attempts inside the selected inclusive date range", () => {
    expect(isWithinSubmittedRange(new Date("2026-08-10T12:00:00Z"), { submittedFrom: new Date("2026-08-10T00:00:00Z"), submittedTo: new Date("2026-08-10T23:59:59Z") })).toBe(true);
    expect(isWithinSubmittedRange(new Date("2026-08-09T23:59:59Z"), { submittedFrom: new Date("2026-08-10T00:00:00Z") })).toBe(false);
    expect(isWithinSubmittedRange(null, {})).toBe(false);
  });

  it("treats only accepted and rejected decisions as publishable feedback", () => {
    expect(isFinalApplicationStatus("accepted")).toBe(true);
    expect(isFinalApplicationStatus("rejected")).toBe(true);
    expect(isFinalApplicationStatus("under review")).toBe(false);
  });

  it("rejects company access to the candidate-only published feedback procedure", async () => {
    const company = appRouter.createCaller(createContext("company"));
    await expect(company.candidate.feedback.listPublished()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
